.. SPDX-License-Identifier: GPL-2.0

====
GPIO
====

.. toctree::
    :maxdepth: 1

    Character Device Userspace API <../../userspace-api/gpio/chardev>
    gpio-aggregator
    gpio-sim
    gpio-virtuser
    Obsolete APIs <obsolete>
